import time
#EXP
start_time = time.time()

from pyscf import gto, scf, cc

mol = gto.M(
    atom='''
O -2.59739269 -0.16216846 0.51842668
H -3.11237273 0.59155925 0.21414681
H -2.99148972 -0.91697774 0.06994740
O 0.00000000 0.00000000 -0.87103097
H 0.76709965 0.02523635 -0.28381455
H -0.76709965 -0.02523635 -0.28381455
O 2.59739269 0.16216846 0.51842668
H 3.11237273 -0.59155925 0.21414681
H 2.99148972 0.91697774 0.06994740
    ''',  # 分子坐标（Angstrom）
    basis = 'sto-3g',
    symmetry = True,
    charge=0,
    spin=0,
    verbose=4  # 输出计算日志
)
mf = scf.HF(mol).run()
# Note that the line following these comments could be replaced by
# mycc = cc.CCSD(mf)
# mycc.kernel()
start_time = time.time()
mycc = cc.CCSD(mf).run()
et = mycc.ccsd_t_saco()
total_energy = mycc.e_tot + et

# 输出结果
print(f"\n=== 计算结果 ===")
print(f"SCF能量: {mf.e_tot:.14f} Hartree")
print(f"CCSD能量: {mycc.e_tot:.14f} Hartree")
print(f"(T)校正项: {et:.14f} Hartree")
print(f"CCSD(T)总能量: {total_energy:.14f} Hartree")

end_time = time.time()
print("耗时: {:.2f}秒".format(end_time - start_time))
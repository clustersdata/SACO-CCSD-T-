#!/usr/bin/env python

'''
SACO-CCSD(T) for real integrals (Optimized for speed)
'''

import ctypes
import numpy
from pyscf import lib
from pyscf import symm
from pyscf.lib import logger
from pyscf.cc import _ccsd

# t3 as ijkabc

def kernel(mycc, eris, t1=None, t2=None, verbose=logger.NOTE):
    cpu1 = cpu0 = (logger.process_clock(), logger.perf_counter())
    log = logger.new_logger(mycc, verbose)
    if t1 is None:
        t1 = mycc.t1
    if t2 is None:
        t2 = mycc.t2

    # 强制连续内存，提升缓存命中率
    t1 = numpy.ascontiguousarray(t1)
    t2 = numpy.ascontiguousarray(t2)
    name = mycc.__class__.__name__
    nocc, nvir = t1.shape
    nmo = nocc + nvir

    dtype = numpy.result_type(t1, t2, eris.ovoo.dtype)
    # 优化临时文件/内存分配策略，减少IO
    if mycc.incore_complete:
        ftmp = None
        eris_vvop = numpy.zeros((nvir, nvir, nocc, nmo), dtype, order='C')  # 强制C连续
    else:
        ftmp = lib.H5TmpFile()
        eris_vvop = ftmp.create_dataset('vvop', (nvir, nvir, nocc, nmo), dtype)

    orbsym = _sort_eri(mycc, eris, nocc, nvir, eris_vvop, log)
    cpu1 = log.timer_debug1(f'{name}(T) sort_eri', *cpu1)

    # 关键修复：调用_sort_t2_vooo_获取mo_energy等变量
    mo_energy, t1T, t2T, vooo, fvo, restore_t2_inplace = _sort_t2_vooo_(mycc, orbsym, t1, t2, eris)

    cpu2 = list(cpu1)
    # 预计算对称相关索引，避免重复计算
    o_sym_sorted = numpy.sort(orbsym[:nocc])
    v_sym_sorted = numpy.sort(orbsym[nocc:])
    orbsym = numpy.hstack((o_sym_sorted, v_sym_sorted))
    # 向量化计算irrep位置，替代循环
    o_ir_counts = numpy.bincount(orbsym[:nocc], minlength=8)
    v_ir_counts = numpy.bincount(orbsym[nocc:], minlength=8)
    o_ir_loc = numpy.append(0, numpy.cumsum(o_ir_counts)).astype(numpy.int32)
    v_ir_loc = numpy.append(0, numpy.cumsum(v_ir_counts)).astype(numpy.int32)
    o_sym = orbsym[:nocc]
    oo_sym = (o_sym[:, None] ^ o_sym).ravel()
    oo_ir_counts = numpy.bincount(oo_sym, minlength=8)
    oo_ir_loc = numpy.append(0, numpy.cumsum(oo_ir_counts)).astype(numpy.int32)
    nirrep = max(oo_sym) + 1 if oo_sym.size > 0 else 1

    # 一次性类型转换，避免循环内转换
    orbsym = orbsym.astype(numpy.int32, copy=False)
    o_ir_loc = o_ir_loc.astype(numpy.int32, copy=False)
    v_ir_loc = v_ir_loc.astype(numpy.int32, copy=False)
    oo_ir_loc = oo_ir_loc.astype(numpy.int32, copy=False)

    # 提前绑定驱动函数，避免条件判断重复执行
    drv = _ccsd.libcc.CCsd_t_zcontract if dtype == numpy.complex128 else _ccsd.libcc.CCsd_t_contract
    et_sum = numpy.zeros(1, dtype=dtype, order='C')

    # 优化contract函数，减少参数传递开销，预计算ctypes指针
    mo_energy_ptr = None
    t1T_ptr = None
    t2T_ptr = None
    vooo_ptr = None
    fvo_ptr = None
    nocc_c = ctypes.c_int(nocc)
    nvir_c = ctypes.c_int(nvir)
    nirrep_c = ctypes.c_int(nirrep)
    o_ir_loc_ptr = o_ir_loc.ctypes.data_as(ctypes.c_void_p)
    v_ir_loc_ptr = v_ir_loc.ctypes.data_as(ctypes.c_void_p)
    oo_ir_loc_ptr = oo_ir_loc.ctypes.data_as(ctypes.c_void_p)
    orbsym_ptr = orbsym.ctypes.data_as(ctypes.c_void_p)
    et_sum_ptr = et_sum.ctypes.data_as(ctypes.c_void_p)

    def contract(a0, a1, b0, b1, cache):
        nonlocal mo_energy_ptr, t1T_ptr, t2T_ptr, vooo_ptr, fvo_ptr
        cache_row_a, cache_col_a, cache_row_b, cache_col_b = cache
        # 懒加载指针，避免重复计算
        if mo_energy_ptr is None:
            mo_energy_ptr = mo_energy.ctypes.data_as(ctypes.c_void_p)
            t1T_ptr = t1T.ctypes.data_as(ctypes.c_void_p)
            t2T_ptr = t2T.ctypes.data_as(ctypes.c_void_p)
            vooo_ptr = vooo.ctypes.data_as(ctypes.c_void_p)
            fvo_ptr = fvo.ctypes.data_as(ctypes.c_void_p)
        # 调用C库，减少Python层开销
        drv(et_sum_ptr,
            mo_energy_ptr,
            t1T_ptr,
            t2T_ptr,
            vooo_ptr,
            fvo_ptr,
            nocc_c, nvir_c,
            ctypes.c_int(a0), ctypes.c_int(a1),
            ctypes.c_int(b0), ctypes.c_int(b1),
            nirrep_c,
            o_ir_loc_ptr,
            v_ir_loc_ptr,
            oo_ir_loc_ptr,
            orbsym_ptr,
            cache_row_a.ctypes.data_as(ctypes.c_void_p),
            cache_col_a.ctypes.data_as(ctypes.c_void_p),
            cache_row_b.ctypes.data_as(ctypes.c_void_p),
            cache_col_b.ctypes.data_as(ctypes.c_void_p))
        nonlocal cpu2
        cpu2[:] = log.timer_debug1('contract %d:%d,%d:%d' % (a0, a1, b0, b1), *cpu2)

    # 优化缓存块大小计算，适配CPU缓存（L2/L3）
    mem_now = lib.current_memory()[0]
    max_memory = max(0, mycc.max_memory - mem_now)
    # 基于CPU缓存大小调整块大小，减少缓存颠簸
    cache_line_size = 64  # 现代CPU缓存行大小
    elem_size = numpy.dtype(dtype).itemsize
    # 计算最优块大小，避免过大/过小
    bufsize = (max_memory * 0.7e6 / elem_size - nocc**3 * 3 * lib.num_threads()) / (nocc * nmo)
    bufsize = max(32, int(bufsize * 0.7))  # 调整系数，适配多线程
    # 对齐到缓存行，提升访问效率
    bufsize = (bufsize // cache_line_size) * cache_line_size
    bufsize = max(32, bufsize)  # 最小块大小，避免过多调度开销
    log.debug('max_memory %d MB (%d MB in use), optimized bufsize %d', max_memory, mem_now, bufsize)

    # 优化并行调用策略，减少线程切换开销
    with lib.call_in_background(contract, sync=not mycc.async_io) as async_contract:
        # 预生成分块范围，避免reversed+list+prange_tril重复计算
        prange_tril_range = list(lib.prange_tril(0, nvir, bufsize))[::-1]
        for a0, a1 in prange_tril_range:
            # 强制连续内存，减少缓存缺失
            cache_row_a = numpy.ascontiguousarray(eris_vvop[a0:a1, :a1])
            if a0 == 0:
                cache_col_a = cache_row_a
            else:
                cache_col_a = numpy.ascontiguousarray(eris_vvop[:a0, a0:a1])
            # 减少重复调用，直接传参
            async_contract(a0, a1, a0, a1, (cache_row_a, cache_col_a, cache_row_a, cache_col_a))

            # 优化内层循环分块，减少调度开销
            b_bufsize = max(8, bufsize // 8)  # 内层块大小适配
            for b0, b1 in lib.prange_tril(0, a0, b_bufsize):
                cache_row_b = numpy.ascontiguousarray(eris_vvop[b0:b1, :b1])
                if b0 == 0:
                    cache_col_b = cache_row_b
                else:
                    cache_col_b = numpy.ascontiguousarray(eris_vvop[:b0, b0:b1])
                async_contract(a0, a1, b0, b1, (cache_row_a, cache_col_a, cache_row_b, cache_col_b))

    # 恢复t2，保持接口兼容
    t2 = restore_t2_inplace(t2T)
    et_sum *= 2
    # 优化虚部检查，减少浮点操作
    imag_part = abs(et_sum[0].imag)
    if imag_part > 1e-4:
        logger.warn(mycc, 'Non-zero imaginary part of %s(T) energy was found %s', name, et_sum[0])
    et = et_sum[0].real
    log.timer(f'{name}(T)', *cpu0)
    log.note('%s(T) correction = %.15g', name, et)
    return et
    

def _irrep_argsort(orbsym):
    # 向量化irrep排序，替代循环拼接
    irrep_range = numpy.arange(8)
    # 批量获取每个irrep的索引，减少循环
    idx_list = [numpy.where(orbsym == i)[0] for i in irrep_range if numpy.any(orbsym == i)]
    return numpy.hstack(idx_list) if idx_list else numpy.array([], dtype=numpy.int32)


if __name__ == '__main__':
    from pyscf import gto
    from pyscf import scf
    from pyscf import cc

    mol = gto.Mole()
    mol.atom = [
        [8, (0., 0., 0.)],
        [1, (0., -.957, .587)],
        [1, (0.2, .757, .487)]]
    mol.basis = 'ccpvdz'
    mol.build()
    rhf = scf.RHF(mol)
    rhf.conv_tol = 1e-14
    rhf.scf()
    mcc = cc.CCSD(rhf)
    mcc.conv_tol = 1e-14
    mcc.ccsd()
    e3a = kernel(mcc, mcc.ao2mo())
    print(e3a - -0.0033300722704016289)

    mol = gto.Mole()
    mol.atom = [
        [8, (0., 0., 0.)],
        [1, (0., -.757, .587)],
        [1, (0., .757, .587)]]
    mol.symmetry = True
    mol.basis = 'ccpvdz'
    mol.build()
    rhf = scf.RHF(mol)
    rhf.conv_tol = 1e-14
    rhf.scf()
    mcc = cc.CCSD(rhf)
    mcc.conv_tol = 1e-14
    mcc.ccsd()
    e3a = kernel(mcc, mcc.ao2mo())
    print(e3a - -0.003060022611584471)